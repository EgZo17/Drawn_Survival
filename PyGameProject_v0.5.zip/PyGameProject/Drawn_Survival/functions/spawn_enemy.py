from classes.Enemy import Enemy
from config import barriers
import random


def spawn_enemy(screen_shift, pos=None):
    player_zone = [[-100 - screen_shift[0], 1920 - screen_shift[0]], [-100 - screen_shift[1], 1080 - screen_shift[1]]]
    if not pos:
        pos = [random.randint(barriers[0][0], barriers[0][1]), random.randint(barriers[1][0], barriers[1][1])]
        while (pos[0] in range(player_zone[0][0], player_zone[0][1])
                and pos[1] in range(player_zone[1][0], player_zone[1][1])):
            pos = [random.randint(barriers[0][0], barriers[0][1]), random.randint(barriers[1][0], barriers[1][1])]
    enemy = Enemy(pos[0] + screen_shift[0], pos[1] + screen_shift[1], pos[0], pos[1])
    '''print(pos[0] + screen_shift[0], pos[1] + screen_shift[1], pos[0], pos[1])
    print(player_zone)
    print(screen_shift)'''
    return enemy
