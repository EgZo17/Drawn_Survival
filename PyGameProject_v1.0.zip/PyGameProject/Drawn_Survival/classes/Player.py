import pygame
import os
from pathlib import Path
from functions.load_image import load_image
from sprite_groups import player_group
from dotenv import load_dotenv
from classes.Shard import Shard
import math

load_dotenv()

SPRITES = Path(os.environ.get('SPRITES'))
PLAYER = SPRITES.joinpath(os.environ.get('PLAYER'))
KILLED_PLAYER = SPRITES.joinpath(os.environ.get('KILLED_PLAYER'))


class Player(pygame.sprite.Sprite):

    player_image = load_image(PLAYER, colorkey=-1)
    killed_player_image = load_image(KILLED_PLAYER, colorkey=-1)

    def __init__(self, pos_x, pos_y):
        super().__init__(player_group)
        self.image = self.player_image
        self.rect = self.image.get_rect().move(pos_x, pos_y)
        self.global_position = [pos_x, pos_y]
        self.alive = True

    def move(self, delta_x, delta_y):
        self.rect = self.image.get_rect().move(self.rect.x + delta_x, self.rect.y + delta_y)

    def find_closest_enemy(self, enemies_list):
        if enemies_list:
            distances = []
            for enemy in enemies_list:
                distances.append(math.hypot(self.global_position[0] - enemy.global_position[0],
                                            self.global_position[1] - enemy.global_position[1]))
            min_dist_index = distances.index(min(distances))
            min_dist = distances[min_dist_index]
            closest_enemy = enemies_list[min_dist_index]
            return closest_enemy, min_dist

    def determine_angle_to_the_closest_enemy(self, closest_enemy):
        delta_x, delta_y = closest_enemy.global_position[0] - self.global_position[0],\
                           closest_enemy.global_position[1] - self.global_position[1]
        dist = math.hypot(delta_x, delta_y)
        cos, sin = delta_x / dist, delta_y / dist
        return cos, sin

    def mark_closest_enemy(self, enemy, screen, screen_shift):
        if enemy:
            pygame.draw.circle(screen, pygame.Color(255, 0, 0), [enemy.global_position[0] + screen_shift[0] + 50,
                                                                 enemy.global_position[1] + screen_shift[1]], 10)

    def make_shot(self, closest_enemy_angle, screen_shift):
        shard = Shard(self.global_position[0] + screen_shift[0] + 50, self.global_position[1] + screen_shift[1] + 50,
                      self.global_position[0] + 50, self.global_position[1] + 50,
                      closest_enemy_angle[0], closest_enemy_angle[1])
        return shard
