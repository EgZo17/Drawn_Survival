import pygame
from config import *
from screen import screen
from functions.convert_resolution import convert_resolution
from functions.generate_level import generate_level
from functions.create_player import create_player
from functions.check_for_being_at_center import check_for_being_at_center
from functions.spawn_enemy import spawn_enemy
from functions.start_screen import start_screen
from functions.final_screen import final_screen
from sprite_groups import *


if __name__ == '__main__':
    pygame.init()
    start_screen()
    clock = pygame.time.Clock()
    generate_level()
    player = create_player()
    enemies = []
    shards = []
    table_color = pygame.Color(139, 87, 58)
    ENEMY_SPAWN_EVENT = pygame.USEREVENT + 1
    pygame.time.set_timer(ENEMY_SPAWN_EVENT, ENEMY_SPAWN_TIME)
    SHARD_SHOOT_EVENT = pygame.USEREVENT + 2
    pygame.time.set_timer(SHARD_SHOOT_EVENT, SHARD_SHOOT_COOLDOWN)
    screen_shift = [0, 0]
    score = 0

    running = True
    while running:
        screen.fill(table_color)
        keys = pygame.key.get_pressed()
        clock.tick(TICK)
        if player.alive:
            if keys[pygame.K_a]:
                if player.global_position[0] >= LEFT_WALL:
                    if check_for_being_at_center([player.rect.x, player.rect.y], 'left'):
                        player.move(-PLAYER_VELOCITY, 0)
                    else:
                        for i in all_sprites_without_player:
                            i.rect.x += PLAYER_VELOCITY
                        screen_shift[0] += PLAYER_VELOCITY
                    player.global_position[0] -= PLAYER_VELOCITY
            if keys[pygame.K_d]:
                if player.global_position[0] <= RIGHT_WALL:
                    if check_for_being_at_center([player.rect.x, player.rect.y], 'right'):
                        player.move(PLAYER_VELOCITY, 0)
                    else:
                        for i in all_sprites_without_player:
                            i.rect.x -= PLAYER_VELOCITY
                        screen_shift[0] -= PLAYER_VELOCITY
                    player.global_position[0] += PLAYER_VELOCITY
            if keys[pygame.K_w]:
                if player.global_position[1] >= TOP_WALL:
                    if check_for_being_at_center([player.rect.x, player.rect.y], 'up'):
                        player.move(0, -PLAYER_VELOCITY)
                    else:
                        for i in all_sprites_without_player:
                            i.rect.y += PLAYER_VELOCITY
                        screen_shift[1] += PLAYER_VELOCITY
                    player.global_position[1] -= PLAYER_VELOCITY
            if keys[pygame.K_s]:
                if player.global_position[1] <= BOTTOM_WALL:
                    if check_for_being_at_center([player.rect.x, player.rect.y], 'down'):
                        player.move(0, PLAYER_VELOCITY)
                    else:
                        for i in all_sprites_without_player:
                            i.rect.y -= PLAYER_VELOCITY
                        screen_shift[1] -= PLAYER_VELOCITY
                    player.global_position[1] += PLAYER_VELOCITY
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                if fullscreen:
                    fullscreen = False
                    convert_resolution(fullscreen)
                else:
                    fullscreen = True
                    convert_resolution(fullscreen)
            if event.type == ENEMY_SPAWN_EVENT:
                enemies.append(spawn_enemy(screen_shift))
            if event.type == SHARD_SHOOT_EVENT and player.alive:
                closest_enemy, dist = player.find_closest_enemy(enemies)
                if dist <= FIRE_RADIUS:
                    new_shard = player.make_shot(player.determine_angle_to_the_closest_enemy(closest_enemy),
                                                 screen_shift)
                    shards.append(new_shard)
        for enemy in enemies:
            if player.alive:
                enemy.move_to_the_player(player.global_position)
                if pygame.sprite.collide_mask(enemy, player):
                    player.image = player.killed_player_image
                    player.alive = False
                    final_screen(score)
        for shard in shards:
            shard.move((SHARD_VELOCITY * shard.cos), (SHARD_VELOCITY * shard.sin))
            if pygame.sprite.spritecollideany(shard, enemies_group):
                for enemy in enemies:
                    if pygame.sprite.collide_rect(shard, enemy):
                        enemy.image = enemy.popped_enemy_image
                        enemies.remove(enemy)
                        score += KILL_BONUS
            if (shard.global_position[0] not in range(-100, all_map_width + 100)
                    or shard.global_position[1] not in range(-100, all_map_height + 100)):
                shards.remove(shard)
                all_sprites_without_player.remove(shard)
        all_sprites_without_player.draw(screen)
        player_group.draw(screen)
        # Метка на ближайшего противника
        # player.mark_closest_enemy(player.find_closest_enemy(enemies), screen, screen_shift)
        """pygame.draw.rect(screen, pygame.Color(0, 0, 0),
                         (center_area_of_the_screen[0] - 200, center_area_of_the_screen[1] - 100, 500, 300),
                         width=3)"""
        pygame.display.flip()
    pygame.quit()
