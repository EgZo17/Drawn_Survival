import pygame
from config import windowed_size


def convert_resolution(to_fullscreen):
    if to_fullscreen:
        pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    else:
        pygame.display.set_mode(windowed_size)
