import pygame
import sys


def terminate():
    pygame.quit()
    sys.exit()
