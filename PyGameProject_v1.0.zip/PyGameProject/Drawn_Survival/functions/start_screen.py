from config import TICK, fs_width, fs_height
from functions.load_image import load_image
from functions.terminate import terminate
from screen import screen
from dotenv import load_dotenv
from pathlib import Path
import pygame
import os

load_dotenv()

TEXTURES = Path(os.environ.get('TEXTURES'))
BACKGROUND = TEXTURES.joinpath(os.environ.get('BACKGROUND'))


def start_screen():
    background_image = load_image(BACKGROUND, -1)
    clock = pygame.time.Clock()
    bg = pygame.transform.scale(background_image, (fs_width, fs_height))
    screen.blit(bg, (0, 0))

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(TICK)
