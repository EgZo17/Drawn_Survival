import pygame
import os
from pathlib import Path
from functions.load_image import load_image
from sprite_groups import shards_group, all_sprites_without_player
from dotenv import load_dotenv
from config import SHARD_VELOCITY
import math

load_dotenv()

SPRITES = Path(os.environ.get('SPRITES'))
SHARD = SPRITES.joinpath(os.environ.get('SHARD'))

player_image = load_image(SHARD, colorkey=-1)


class Shard(pygame.sprite.Sprite):

    def __init__(self, screen_pos_x, screen_pos_y, global_pos_x, global_pos_y, cos, sin):
        super().__init__(shards_group, all_sprites_without_player)
        self.image = player_image
        self.rect = self.image.get_rect().move(screen_pos_x, screen_pos_y)
        self.global_position = [global_pos_x, global_pos_y]
        self.cos = cos
        self.sin = sin

    def move(self, delta_x, delta_y):
        self.rect = self.image.get_rect().move(self.rect.x + int(delta_x), self.rect.y + int(delta_y))
        self.global_position[0] += int(delta_x)
        self.global_position[1] += int(delta_y)

    """def move_to_the_closest_enemy(self, enemy):
        delta_x, delta_y = enemy.global_position[0] - self.global_position[0],\
                           enemy.global_position[1] - self.global_position[1]
        dist = math.hypot(delta_x, delta_y)
        if dist <= 2:
            cos, sin = 0, 0
            return True
        else:
            cos, sin = delta_x / dist, delta_y / dist
        self.move(cos * SHARD_VELOCITY, sin * SHARD_VELOCITY)
        return False"""
