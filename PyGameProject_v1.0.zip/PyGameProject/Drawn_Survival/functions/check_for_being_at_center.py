from config import center_area_of_the_screen


def check_for_being_at_center(t_l_corn_pos: list, direction):
    if t_l_corn_pos[0] <= center_area_of_the_screen[0] - 200 and direction == 'left':
        return False
    if t_l_corn_pos[0] >= center_area_of_the_screen[0] + 200 and direction == 'right':
        return False
    if t_l_corn_pos[1] <= center_area_of_the_screen[1] - 120 and direction == 'up':
        return False
    if t_l_corn_pos[1] >= center_area_of_the_screen[1] + 120 and direction == 'down':
        return False
    return True
