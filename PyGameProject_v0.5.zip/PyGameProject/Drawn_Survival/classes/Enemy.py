import pygame
import os
from pathlib import Path
from functions.load_image import load_image
from sprite_groups import all_sprites_without_player, enemies_group
from config import ENEMY_VELOCITY
from dotenv import load_dotenv
import math

load_dotenv()

SPRITES = Path(os.environ.get('SPRITES'))
ENEMY = SPRITES.joinpath(os.environ.get('ENEMY'))
POPPED_ENEMY = SPRITES.joinpath(os.environ.get('POPPED_ENEMY'))


class Enemy(pygame.sprite.Sprite):

    enemy_image = load_image(ENEMY, colorkey=-1)
    popped_enemy_image = load_image(POPPED_ENEMY, colorkey=-1)

    def __init__(self, screen_pos_x, screen_pos_y, global_pos_x, global_pos_y):
        super().__init__(enemies_group, all_sprites_without_player)
        self.image = self.enemy_image
        self.rect = self.image.get_rect().move(screen_pos_x, screen_pos_y)
        self.global_position = [global_pos_x, global_pos_y]
        self.killed = False

    def move(self, delta_x, delta_y):
        self.rect = self.image.get_rect().move(self.rect.x + int(delta_x), self.rect.y + int(delta_y))
        self.global_position[0] += int(delta_x)
        self.global_position[1] += int(delta_y)

    def move_to_the_player(self, player_pos):
        delta_x, delta_y = player_pos[0] - self.global_position[0], player_pos[1] - self.global_position[1]
        dist = math.hypot(delta_x, delta_y)
        if dist <= 2:
            cos, sin = 0, 0
        else:
            cos, sin = delta_x / dist, delta_y / dist
        self.move(cos * ENEMY_VELOCITY, sin * ENEMY_VELOCITY)
