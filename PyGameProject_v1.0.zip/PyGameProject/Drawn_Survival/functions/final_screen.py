from config import TICK, fs_width, fs_height
from functions.load_image import load_image
from functions.terminate import terminate
from screen import screen
from dotenv import load_dotenv
from pathlib import Path
import pygame
import os

load_dotenv()

TEXTURES = Path(os.environ.get('TEXTURES'))
RESULT_SCREEN = TEXTURES.joinpath(os.environ.get('RESULT_SCREEN'))


def final_screen(score):
    str_score = str(score)
    result_screen_image = load_image(RESULT_SCREEN)
    clock = pygame.time.Clock()
    res = pygame.transform.scale(result_screen_image, (fs_width, fs_height))
    screen.blit(res, (0, 0))
    font = pygame.font.Font(None, 150)
    string_rendered = font.render(str_score, 1, pygame.Color('black'))
    intro_rect = string_rendered.get_rect()
    intro_rect.top = 900
    intro_rect.x = 350
    screen.blit(string_rendered, intro_rect)
    attempts = open('attempts.txt', 'r')
    current_attempt = int(attempts.readline()) + 1
    attempts.close()
    attempts = open('attempts.txt', 'w')
    attempts.write(str(current_attempt))
    attempts.close()
    scoreboard = open('scoreboard.txt', 'a')
    scoreboard.write(f'attempt: {str(current_attempt)}; score: {str(score)}.' + '\n')
    scoreboard.close()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                terminate()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
                return
        pygame.display.flip()
        clock.tick(TICK)
