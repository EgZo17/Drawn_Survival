import pygame

pygame.init()
pygame.display.set_caption('Drawn Survival')
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
