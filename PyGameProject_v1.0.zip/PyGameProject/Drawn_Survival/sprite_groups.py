import pygame

all_sprites_without_player = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
enemies_group = pygame.sprite.Group()
shards_group = pygame.sprite.Group()
