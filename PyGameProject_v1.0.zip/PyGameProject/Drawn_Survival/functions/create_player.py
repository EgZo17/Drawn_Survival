from classes.Player import Player
from config import center_area_of_the_screen


def create_player(pos=None):
    if not pos:
        pos = center_area_of_the_screen
    player = Player(pos[0], pos[1])
    return player
