import pygame
import os
from config import tile_width, tile_height
from pathlib import Path
from functions.load_image import load_image
from sprite_groups import all_sprites_without_player, tiles_group
from dotenv import load_dotenv

load_dotenv()

TEXTURES = Path(os.environ.get('TEXTURES'))
PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('PAPER_TEXTURE'))
TORN_BOTTOM_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_BOTTOM_PAPER_TEXTURE'))
TORN_LEFT_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_LEFT_PAPER_TEXTURE'))
TORN_RIGHT_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_RIGHT_PAPER_TEXTURE'))
TORN_TOP_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_TOP_PAPER_TEXTURE'))
TORN_TOP_LEFT_CORNER_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_TOP_LEFT_CORNER_PAPER_TEXTURE'))
TORN_TOP_RIGHT_CORNER_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_TOP_RIGHT_CORNER_PAPER_TEXTURE'))
TORN_BOTTOM_LEFT_CORNER_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_BOTTOM_LEFT_CORNER_PAPER_TEXTURE'))
TORN_BOTTOM_RIGHT_CORNER_PAPER_TEXTURE = TEXTURES.joinpath(os.environ.get('TORN_BOTTOM_RIGHT_CORNER_PAPER_TEXTURE'))

tile_images = {'paper': load_image(PAPER_TEXTURE),
               't_bottom_paper': load_image(TORN_BOTTOM_PAPER_TEXTURE),
               't_left_paper': load_image(TORN_LEFT_PAPER_TEXTURE),
               't_right_paper': load_image(TORN_RIGHT_PAPER_TEXTURE),
               't_top_paper': load_image(TORN_TOP_PAPER_TEXTURE),
               't_top_left_paper': load_image(TORN_TOP_LEFT_CORNER_PAPER_TEXTURE),
               't_top_right_paper': load_image(TORN_TOP_RIGHT_CORNER_PAPER_TEXTURE),
               't_bottom_left_paper': load_image(TORN_BOTTOM_LEFT_CORNER_PAPER_TEXTURE),
               't_bottom_right_paper': load_image(TORN_BOTTOM_RIGHT_CORNER_PAPER_TEXTURE)}


class Tile(pygame.sprite.Sprite):

    def __init__(self, tile_type, tile_pos_x, tile_pos_y):
        super().__init__(tiles_group, all_sprites_without_player)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(tile_width * tile_pos_x, tile_height * tile_pos_y)
