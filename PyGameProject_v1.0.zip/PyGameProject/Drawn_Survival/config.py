import random

fullscreen_size = fs_width, fs_height = 1920, 1080
windowed_size = w_width, w_height = 1280, 720
center_area_of_the_screen = [fs_width // 2 - 50, fs_height // 2 - 50]
TICK = 60
PLAYER_VELOCITY = 3
ENEMY_VELOCITY = 3
SHARD_VELOCITY = 7
ENEMY_SPAWN_TIME = 1000
SHARD_SHOOT_COOLDOWN = 5000
POPPED_ENEMY_REMOVAL_COOLDOWN = 1000
FIRE_RADIUS = 600
fullscreen = True
tile_width = tile_height = 100
playable_map_width_in_tiles = random.randint(30, 70)  # 50
playable_map_height_in_tiles = random.randint(30, 70)  # 50
all_map_width_in_tiles = playable_map_width_in_tiles + 2
all_map_height_in_tiles = playable_map_height_in_tiles + 2
playable_map_width = playable_map_width_in_tiles * tile_width
playable_map_height = playable_map_height_in_tiles * tile_height
all_map_width = all_map_width_in_tiles * tile_width
all_map_height = all_map_height_in_tiles * tile_height
barriers = [(tile_width, playable_map_width_in_tiles * tile_width + 1),
            (tile_height, playable_map_height_in_tiles * tile_height + 1)]
LEFT_WALL = barriers[0][0]
RIGHT_WALL = barriers[0][1]
TOP_WALL = barriers[1][0]
BOTTOM_WALL = barriers[1][1]
KILL_BONUS = 100
