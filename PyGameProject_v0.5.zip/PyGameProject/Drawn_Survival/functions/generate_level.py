from classes.Tile import Tile
from config import playable_map_width_in_tiles, playable_map_height_in_tiles, \
    all_map_width_in_tiles, all_map_height_in_tiles


def generate_level():
    Tile('t_top_left_paper', 0, 0)
    for x in range(1, playable_map_width_in_tiles + 1):
        Tile('t_top_paper', x, 0)
    Tile('t_top_right_paper', playable_map_width_in_tiles + 1, 0)
    for y in range(1, playable_map_height_in_tiles + 1):
        Tile('t_left_paper', 0, y)
        for x in range(1, playable_map_width_in_tiles + 1):
            Tile('paper', x, y)
        Tile('t_right_paper', playable_map_width_in_tiles + 1, y)
    Tile('t_bottom_left_paper', 0, playable_map_height_in_tiles + 1)
    for x in range(1, playable_map_width_in_tiles + 1):
        Tile('t_bottom_paper', x, playable_map_height_in_tiles + 1)
    Tile('t_bottom_right_paper', playable_map_width_in_tiles + 1, playable_map_height_in_tiles + 1)
